#!/usr/bin/python

import sys

from trac.env import Environment
from trac.ticket.model import Ticket

env = Environment('/usr/portage/dev-python/docutils/test')

# Create a new ticket
if sys.argv[1] == "new" :
    tkt = Ticket(env)
    tkt['reporter']     = sys.argv[2]
    tkt['summary']      = sys.argv[3]
    tkt['description']  = sys.argv[4]
    tkt['owner']        = sys.argv[5]
    tkt['status']       = 'new'
    tkt.insert()
    print tkt.id

# Set the status of an ticket
if sys.argv[1] == "set_state" :
    tkt = Ticket(env, sys.argv[2])
    tkt['status']       = sys.argv[3]
    tkt.save_changes(author='system', comment=sys.argv[4])

# Close a ticket
if sys.argv[1] == "close" :
    tkt = Ticket(env, sys.argv[2])
    tkt['status']       = 'closed'
    tkt['resolution']   = 'fixed'
    tkt.save_changes(author='system', comment='System closed the ticket')

# Reopen a ticket:
if sys.argv[1] == "reopen" :
    tkt = Ticket(env, sys.argv[2])
    tkt['status']       = 'new'
    tkt['resolution']   = ''
    tkt.save_changes(author='system', comment='System reopened the ticket')

# Delete a ticket
if sys.argv[1] == "delete" :
    tkt = Ticket(env, sys.argv[2])
    tkt.delete()

# Get the current status
if sys.argv[1] == "get_status" :
    tkt = Ticket(env, sys.argv[2])
    print tkt['status']

# Change the owner of a ticket
if sys.argv[1] == "chown" :
    tkt = Ticket(env, sys.argv[2])
    tkt['status']       = sys.argv[3]
